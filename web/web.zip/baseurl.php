<?php
	$baseurl = 'http://localhost/tripsaintmartin/';
?>
