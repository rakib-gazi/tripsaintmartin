<?php 
	ob_start();
?>
<!DOCTYPE html>
<html>
	<?php include('loginHead.php');?>
	<body >
		<header>
			<!-- Navbar -->
			<nav class="bg-cyan-950 px-4 py-3 text-white fixed top-0 left-0 right-0 z-50">
				<div class="mx-4 flex justify-center items-center ">
					<p class="text-white font-bold text-2xl py-4">Trip Saint Martin Admin Panel</p>
				</div>
			</nav>
		</header>